import lejos.nxt.Motor;
import lejos.nxt.NXTRegulatedMotor;
import lejos.nxt.SensorPort;
import lejos.nxt.Sound;
import lejos.nxt.UltrasonicSensor;

public class USLocalizer {
	public enum LocalizationType { FALLING_EDGE, RISING_EDGE };
	public static double ROTATION_SPEED = 30;
	static NXTRegulatedMotor leftMotor = Motor.A;
	static NXTRegulatedMotor rightMotor = Motor.B;
	
	public Odometer odo;
	private TwoWheeledRobot robot = new TwoWheeledRobot(Motor.A, Motor.B);
	private UltrasonicSensor us = new UltrasonicSensor(SensorPort.S2);
	private LocalizationType locType;
	private Navigation navigate = new Navigation(odo);
	
	static double angleA = 0, angleB = 0;
	
	int filterControl = 0;
	int FILTER_OUT = 20;

	public USLocalizer(Odometer odo, UltrasonicSensor us, LocalizationType locType) {
		this.odo = odo;
		
		this.us = us;
		this.locType = locType;
		
		// switch off the ultrasonic sensor
		us.off();
	}
	
	public void doLocalization() {
		
		
		
		double detect = 50;
		double margin = 10;
		
		robot.setRotationSpeed(ROTATION_SPEED);
		
		
		if (locType == LocalizationType.FALLING_EDGE) {
			
			robot.setRotationSpeed(ROTATION_SPEED);
			boolean wall = true;
			while(true){
				
				
				if(getFilteredData() > (detect + margin)){
					wall = false;
				}
				if(!wall && getFilteredData() < (detect - margin)){
					wall = true;
					Sound.beep();
					angleA = odo.getPosition()[2];

					
					robot.setRotationSpeed(-ROTATION_SPEED);
					
					
					while(robot.getRotSpeed() < 0){
						if(getFilteredData() > detect + margin){
							wall = false;
							
						}
						if(!wall && getFilteredData() < detect - margin){
							wall = true;
							Sound.beep();
							angleB = odo.getPosition()[2];
							//robot.setRotationSpeed(0);
							
							Motor.A.stop();
							Motor.B.stop();
							
							break;
						}
					}
					
					
					
				}
				if(angleA != 0 && angleB != 0){
					break;
				}
			}
			double trueAng = 0;
			if(angleA > angleB){
				trueAng = odo.getAng() + (225.0 - (angleA + angleB) / 2.0) + 180;
			}else{
				trueAng = odo.getAng() + (45.0 - (angleA + angleB) / 2.0) + 180;
			}
			
			double[] position = new double[3];
			boolean[] upd = {false, false, true};
			position[2] = trueAng;
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {	}
			
			odo.setPosition(position , upd);
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {	}
			
			navigate.turnTo(0, true);
			
		
		} else {
			/*
			 * The robot should turn until it sees the wall, then look for the
			 * "rising edges:" the points where it no longer sees the wall.
			 * This is very similar to the FALLING_EDGE routine, but the robot
			 * will face toward the wall for most of it.
			 */
			robot.setRotationSpeed(ROTATION_SPEED);
			boolean wall = false;
			while(true){
				
				
				if(getFilteredData() < (detect - margin)){
					wall = true;
				}
				if(wall && getFilteredData() > (detect + margin)){
					wall = false;
					Sound.beep();
					angleA = odo.getPosition()[2];

					
					robot.setRotationSpeed(-ROTATION_SPEED);
					
					
					while(robot.getRotSpeed() < 0){
						if(getFilteredData() < detect - margin){
							wall = true;
							
						}
						if(wall && getFilteredData() > detect + margin){
							wall = false;
							Sound.beep();
							angleB = odo.getPosition()[2];
							//robot.setRotationSpeed(0);
							
							Motor.A.stop();
							Motor.B.stop();
							
							break;
						}
					}
					
					
					
				}
				if(angleA != 0 && angleB != 0){
					break;
				}
			}
			double trueAng = 0;
			if(angleA > angleB){
				trueAng = odo.getAng() + (225.0 - (angleA + angleB) / 2.0) ;
			}else{
				trueAng = odo.getAng() + (45.0 - (angleA + angleB) / 2.0) ;
			}
			
			double[] position = new double[3];
			boolean[] upd = {false, false, true};
			position[2] = trueAng;
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {	}
			
			odo.setPosition(position , upd);
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {	}
			
			navigate.turnTo(0, true);
			
			
			//while(true){
				
				
				
				
			//navigate.turnTo(1 , false);
			
				
				
			//}
			
			
			
			
			
			//
			// FILL THIS IN
			//
		}
	}
	
	private int getFilteredData() {
		int distance;
		int filtered = 0;

	    // there will be a delay here
		distance = us.getDistance();
		
		// rudimentary filter
		if (distance == 255 && filterControl < FILTER_OUT) {
			// bad value, do not set the distance var, however do increment the filter value
			filterControl ++;
		} else if (distance == 255){
			// true 255, therefore set distance to 255
			filtered = distance;
		} else {
			// distance went below 255, therefore reset everything.
			filterControl = 0;
			filtered = distance;
		}
		
		return filtered;
	}
	
//	public boolean findWall(){
//		
//		double detect = 20;
//		double margin = 3;
//		
//		if(getFilteredData() < detect - margin){
//			
//			return true;
//		
//		}else if(getFilteredData() > detect + margin){
//			
//			return true;
//		
//		}
//	}

}
