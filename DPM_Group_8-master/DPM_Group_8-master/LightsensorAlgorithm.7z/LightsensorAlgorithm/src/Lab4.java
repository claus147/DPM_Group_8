import lejos.nxt.*;

public class Lab4 {
	static final int DEFAULT_PERIOD = 200;

	static Odometer odo = new Odometer( Motor.A, Motor.B, DEFAULT_PERIOD, true);
	public static void main(String[] args) {
		// setup the odometer, display, and ultrasonic and light sensors
		TwoWheeledRobot patBot = new TwoWheeledRobot(Motor.A, Motor.B);
		
		
		
		UltrasonicSensor us = new UltrasonicSensor(SensorPort.S2);
		LightSensor ls = new LightSensor(SensorPort.S1);
		int buttonChoice;

		do {
			// clear the display
			LCD.clear();

			// ask the user whether the motors should drive in a square or float
			LCD.drawString("<  Left | Right     >", 0, 0);
			LCD.drawString("        |                 ", 0, 1);
			LCD.drawString(" falling|  ", 0, 2);
			LCD.drawString(" edge   |  ", 0, 3);
			

			buttonChoice = Button.waitForAnyPress();
		} while (buttonChoice != Button.ID_LEFT
				&& buttonChoice != Button.ID_RIGHT);
		// perform the ultrasonic localization
		
		if (buttonChoice == Button.ID_LEFT) {
			
			LCDInfo lcd = new LCDInfo(odo);
			USLocalizer usl = new USLocalizer(odo, us, USLocalizer.LocalizationType.FALLING_EDGE);
		//	usl.doLocalization();
			LightLocalizer lsl = new LightLocalizer(odo, ls);
			lsl.doLocalization();	
		} else {
			LCDInfo lcd = new LCDInfo(odo);
			USLocalizer usl = new USLocalizer(odo, us, USLocalizer.LocalizationType.RISING_EDGE);
		//	usl.doLocalization();
			

		}
	
		
		// perform the light sensor localization
//		LightLocalizer lsl = new LightLocalizer(odo, ls);
//		lsl.doLocalization();			
		
		Button.waitForAnyPress();
	}

}
