import lejos.nxt.LightSensor;
import lejos.nxt.Motor;
import lejos.nxt.Sound;

public class LightLocalizer {
	private Odometer odo;
	
	private TwoWheeledRobot robot = new TwoWheeledRobot(Motor.A, Motor.B);
	private LightSensor ls;
	private int lightReading;
	private Navigation navigate = new Navigation(odo);
	public static double [] thetas = new double [4]; //first 2 entries are for start for x then y last 2 are for end x then y
	public static double ROTATION_SPEED = 30;
	double oldValue = 0;
	double newValue =0;
	
	static boolean encounterLine = false;
	
	public LightLocalizer(Odometer odo, LightSensor ls) {
		this.odo = odo;
		this.robot = odo.getTwoWheeledRobot();
		this.ls = ls;
		
		// turn on the light
		ls.setFloodlight(true);
	}
	
	public void doLocalization() {
		// drive to location listed in tutorial
		// start rotating and clock all 4 gridlines
		// do trig to compute (0,0) and 0 degrees
		// when done travel to (0,0) and turn to 0 degrees
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// there is nothing to be done here because it is not expected that
			// the odometer will be interrupted by another thread
		}
		
	//	navigate.turnTo(45, true);
	//	navigate.goForward(12);
	//	robot.setRotationSpeed(ROTATION_SPEED);

		/* START DATA READING FROM CLAUS */
		
		
		int average = 0 ;
		double [] lReadings = new double[5]; //5 readings stored at each instance
		
		for (int i = 0; i < 5; i++){ //reading 5 times, once every second - initial array
			lReadings[i] = getLightReading();
			try { Thread.sleep(200); } catch (InterruptedException e) {} //sleep 1/4 of a sec
		}
		
		
		for (int i = 0; i < 5; i++){
			average = average + (int) lReadings[i]; //adding up the values in array
		}
		average = average/5;
		
		int prevAvg = 0;
		int counter = 0;				//count for array of light readings
		int threshold;
		
		robot.setRotationSpeed(ROTATION_SPEED);
		odo.getAng();
		int count = 0;	//number of lines crossed
		getLightReading();	
		while (count < 4){ //while not crossing the negative y axis
			
			//300 milisecond sleep (if reduced could increase odo's theta accuracy
			//try { Thread.sleep(300); } catch (InterruptedException e) {}	
			
			if (counter == 5) //always wrap around
				counter = 0;
			lReadings[counter] = getLightReading();
			
			prevAvg = average;
			average = 0; //reset the average
			for (int i = 0; i < 5; i++){
				average = average + (int) lReadings[i]; //adding up the values in array
			}
			average = average/5;		//getting actual average
			counter++;
			
			threshold = (int) (average * 0.01); //1% threshold
			//prevLR = lightReading;
			//getLightReading();						//get the light reading
			
			odo.getAng();					//get pos from odometer
			if((prevAvg - average) > threshold  ){
	//		if(lightReading < darknessEdge){		//if passes a line
	
				
				thetas[count] = odo.getAng();				//"thetas" hold the value for (init theta of x, y and final theta x,y) 
													//		see initialised variables for details 
				count++;					
				Sound.beepSequence();				//perform beep
			}
			
		}

		
		/* END DATA READING FROM CLAUS */
		/*	START TUAN
		double[] angle= new double[4];
		while(true){
			newValue =	ls.readValue();

			
			
			

			
			//if the difference is large, there is a black line
			//if requirement is met, the robot will beep.
			if( newValue - oldValue <= -2){
				angle[count] = odo.getAng();
				
				
				Sound.beep();
				count ++;
				if(count == 4){
					
					robot.setRotationSpeed(0);
					break;
				}
				
				
			}
			oldValue = newValue;
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				// there is nothing to be done here because it is not expected that
				// the odometer will be interrupted by another thread
			}
		}
			 END TUAN	*/
		
		
		//was 21.5
		double trueX = -1 * 21.5 * Math.cos((thetas[3] - thetas[1]) / 2.0);
		double trueY = -1 * 21.5 * Math.cos((thetas[2] - thetas[0]) / 2.0);
		// double angCorrection = 90 - (odo.getAng() - 180) + ((thetas[2] - thetas[0]) / 2.0);
		double angCorrection = 90 - (odo.getAng() - 180) + ((thetas[2] - thetas[0]) / 2.0);
		double trueAng = odo.getAng() + angCorrection;
		double[] pos = {trueX, trueY, trueAng};
		boolean[] upd = {true,true,true};
		odo.setPosition(pos, upd);
		
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// there is nothing to be done here because it is not expected that
			// the odometer will be interrupted by another thread
		}
		
		// navigate.travelTo(0, 0);
		while(true){
			if(count == 4){
				robot.setRotationSpeed(0);
				break;
		}
		}
		 navigate.turnTo( 90 + 12, true);

		}

	
	
	
	public int getLightReading(){				//to read light sensor
		 // wait for the ping to complete
		try { Thread.sleep(50); } catch (InterruptedException e) {}		//50 milisecond sleep
		
		lightReading = ls.getNormalizedLightValue();
		//lightReading = ls.readValue();
		
		return lightReading;
	}


}
